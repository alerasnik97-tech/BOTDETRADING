# MANIPULANTE

Phase25 Authority. Phase37D verdict: `FTMO_TRIAL_BLOCKED_NEWS_PROVIDER`. Real blocked. Strategy unchanged.
