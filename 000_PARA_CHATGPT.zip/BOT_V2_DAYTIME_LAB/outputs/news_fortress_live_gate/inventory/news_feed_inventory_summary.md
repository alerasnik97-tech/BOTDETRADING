# NEWS FEED INVENTORY SUMMARY

| Source ID | Path | Rows | Start | End | High Impact | Status |
| :--- | :--- | :--- | :--- | :--- | :--- | :--- |
| NEWS_PRIMARY | C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\research_lab\data\news\news_events.csv | 504 | 2020-01-03T15:00:00+00:00 | 2025-04-03T14:00:00+00:00 | 504 | LOADED_OK |
| NEWS_COVERAGE_PH17 | C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\BOT_V2_DAYTIME_LAB\outputs\phase17_news_feed_reliability\calendar_audit\news_calendar_coverage.csv | 6 | 2020 | 2025 | 0 | LOADED_OK |
