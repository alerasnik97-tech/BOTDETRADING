# NEWS FORTRESS LIVE GATE: SNAPSHOT Y CUARENTENA

## 1. Declaración de Intenciones
News Fortress no es una estrategia de trading, sino una capa institucional de seguridad. Su objetivo es actuar como un "Gate" (puerta) obligatorio que bloquea la operativa ante eventos de alto impacto, fallos de datos o ambigüedad en el calendario.

## 2. Restricciones Operativas
- **No Real Trading**: Este módulo se diseña para validación y Forward Demo.
- **No MT5 / cTrader**: La integración es lógica y documental en esta fase.
- **Protección de Autoridad**: No se modifican Phase 18 ni SCBI.
- **Fail-Closed**: Ante cualquier duda (falta de feed, feed expirado, evento desconocido), la respuesta por defecto es **BLOCK**.

## 3. Contexto de Seguridad
El sistema responde a la necesidad crítica de evitar pérdidas por volatilidad extrema no gestionada. Se prohíbe explícitamente operar sin Stop Loss y sin una validación positiva del News Gate.

---
**Estado Actual**: Fase 0 Completada. Iniciando Inventario de Feeds (Fase 1).
