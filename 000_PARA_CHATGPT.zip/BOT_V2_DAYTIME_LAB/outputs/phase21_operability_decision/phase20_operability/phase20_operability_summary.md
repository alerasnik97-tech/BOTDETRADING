# PHASE 20 OPERABILITY AUDIT SUMMARY

## 1. Métricas de Operabilidad (Base: TP 2.0R, BE 1.0R)
- **PF**: 1.68
- **Winrate**: 33.9%
- **Max Drawdown**: -14.0R
- **Max Streak**: 9 pérdidas consecutivas.
- **Expectancy**: 0.28R por trade.

## 2. Análisis Psicológico
La racha de 9 pérdidas consecutivas es el mayor desafío. Un usuario con riesgo del 1% por trade vería una caída del 9% en su cuenta en el peor de los escenarios. Sin embargo, el PF de 1.68 compensa con creces estas rachas.

## 3. Sensibilidad a Costos
- **Baseline**: PF 1.68
- **+0.5 pip**: PF 1.61
- **+1.0 pip**: PF 1.54
- **Veredicto**: El "edge" sobrevive cómodamente a condiciones reales de spread y slippage.

---
**Conclusión**: Phase 20 es un candidato robusto. La variante de 2.0R es la más rentable, pero se explorarán perfiles con mayor Winrate para facilitar la ejecución.
