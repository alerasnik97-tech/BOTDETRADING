# Phase 17 Preflight - News Feed Reliability

## Status: PHASE16_POST_NEWS_CANDIDATE_LOCKED
- **Phase 16 Reference:** Combo A (CPI/NFP/ECB) | PF 2.03 | Sample 53.
- **Constraints:**
    - No real trading / MT5.
    - No modification of SCBI.
    - Mandatory news audit before Forward Gate.

## Scope
1. Audit historical news calendar for integrity and coverage.
2. Build a robust family normalizer and signal generation module.
3. Validate the module by reproducing Phase 16 exactly.
4. Stress test family inclusion and costs.
