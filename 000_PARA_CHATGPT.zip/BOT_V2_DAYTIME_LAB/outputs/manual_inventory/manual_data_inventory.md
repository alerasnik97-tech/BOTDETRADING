# manual_data_inventory.md

**Fecha:** 2026-04-25
**Origen:** `C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\DATA MANUAL`

## 1. Archivos Identificados
- `analytics (1).csv`: Registro principal de operaciones.
- `1.png` a `7.png`: Screenshots de setups técnicos (presumiblemente ejemplos de CHoCH/FVG).

## 2. Formato y Estructura (analytics (1).csv)
- **Columnas:** 22 columnas (id, dateStart, dateEnd, pair, uPnL, rPnL, side, entryPrice, initalSL, maxTP, idealTP, amount, amountClosed, status, day, tags, avgClosePrice, avgRiskReward, maxRiskReward, exchangeRate, initialBalance, currentRealizedBalance).
- **Muestra Estimada:** 841 registros.
- **Periodo Cubierto:** ~2020 a 2026.

## 3. Disponibilidad de Datos Críticos
- [x] **Horarios:** `dateStart` (Entrada), `dateEnd` (Salida).
- [x] **Dirección:** `side` (buy/sell).
- [x] **Precios:** Entrada, SL y Salida real.
- [x] **Resultado R:** `avgRiskReward`.
- [x] **Niveles Barridos:** No explicitamente en el CSV (requiere análisis visual o deducción).
- [x] **Timeframe de Entrada:** No explicitamente en el CSV (se deduce de la duración del trade).

## 4. Calidad de la Data
La data es de alta calidad operativa (registros reales de una cuenta), pero carece de "tags" técnicos descriptivos (como "CHoCH" o "H1 Sweep") en la mayoría de las filas. La reconstrucción del edge requerirá cruzar estos registros con los precios históricos certificados.
