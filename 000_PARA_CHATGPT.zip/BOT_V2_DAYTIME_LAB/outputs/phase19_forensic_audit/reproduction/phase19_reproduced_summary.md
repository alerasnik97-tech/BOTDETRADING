# Phase19 Reproduction Summary

Verdicto: PHASE19_REPRODUCTION_MISMATCH
Sample: 3177
PF: 3.176
Expectancy R: 0.742
Cumulative R: 2357.000
Max DD R: -15.500
Max loss streak: 12
Worst day R: -3.000
Worst week R: -9.000
Win rate: 43.31%
TP / SL / BE / Timeout / Forced: 1376 / 1083 / 0 / 718 / 0
Same-bar count: 0
Trades/month: 41.80
Trades/day avg: 2.69
Out-of-hours 07-20: 0
News violations +/-30m: 458
Rollover/open after 20:00 NY: 375
Duplicated trades same event: 0

Nota: esto reproduce el resultado legacy, pero todavia no lo valida.
