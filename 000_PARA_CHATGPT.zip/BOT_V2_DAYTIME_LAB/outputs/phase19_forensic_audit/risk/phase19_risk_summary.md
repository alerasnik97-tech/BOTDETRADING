# Phase19 Drawdown / Risk

Verdicto: PHASE19_RISK_WARNING
Max DD R: -15.500
Max loss streak: 12
Worst day R: -3.000
Worst week R: -9.000
Worst month R: -4.000
Average monthly R: 31.013
Monthly volatility R: 14.006
