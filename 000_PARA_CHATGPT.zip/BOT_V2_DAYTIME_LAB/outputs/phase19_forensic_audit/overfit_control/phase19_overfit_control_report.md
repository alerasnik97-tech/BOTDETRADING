# Phase19 Overfit Control

Verdicto: PHASE19_OVERFIT_HIGH_RISK
Tested variants counted: 69
Raw PF: 3.176
Penalized PF: 0.851
Final deflated edge score: 6.70
