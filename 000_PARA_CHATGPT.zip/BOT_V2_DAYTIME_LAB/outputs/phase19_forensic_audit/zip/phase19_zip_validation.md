# Phase19 ZIP Validation

Verdicto: ZIP_VALIDATED
Existe: True
Size bytes: 704135
testzip: None
Entry count: 96
Contains Phase19 forensic: True
Contains secrets: False
Contains heavy data: False
