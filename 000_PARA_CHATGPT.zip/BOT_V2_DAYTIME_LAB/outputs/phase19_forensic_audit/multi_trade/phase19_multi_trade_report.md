# Phase19 Multi-Trade Audit

Verdicto: PHASE19_MULTI_TRADE_INVALIDATES_PHASE19
Max trades/dia: 3
Dias 1/2/3 trades: 121 / 124 / 936
PF trade 1: 2.827
PF trade 2: 3.293
PF trade 3: 3.570
Expectancy trade 1: 0.687
Expectancy trade 2: 0.750
Expectancy trade 3: 0.802
Max daily loss R: -3.000
Duplicados mismo evento: 0
Trades con mismo timestamp: 2145
Solapamientos: 1671

Conclusion: el limite de 3 trades/dia existe como corte por cantidad, pero no modela secuencia real ni evita duplicados/solapamientos.
