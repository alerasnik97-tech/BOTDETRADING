# Phase19 TP/SL Math Audit

Verdicto: PHASE19_TP_SL_WARNING
Risk <= 0: 0
Targets imposibles: 0
Violaciones TP 2.5R: 0
SL igual a entrada sin BE: 0
Duracion <= una vela M3: 67
