# Phase19 Forensic vs Manual

Phase19 legacy PF reproducido: 3.176
Phase19 sample reproducido: 3177
Manual PF referencia: 1.640
Manual sample referencia: 841
Nota: manual monetario; R-normalizado PF 1.53
Conclusion: Phase19 no puede reemplazar esta referencia porque la auditoria forense encontro fallas invalidantes.
