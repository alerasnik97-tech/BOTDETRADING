# Phase19 Forensic vs Phase18 baseline

Phase19 legacy PF reproducido: 3.176
Phase19 sample reproducido: 3177
Phase18 baseline PF referencia: 1.630
Phase18 baseline sample referencia: 1040
Nota: diurna protegida; no reemplazada
Conclusion: Phase19 no puede reemplazar esta referencia porque la auditoria forense encontro fallas invalidantes.
