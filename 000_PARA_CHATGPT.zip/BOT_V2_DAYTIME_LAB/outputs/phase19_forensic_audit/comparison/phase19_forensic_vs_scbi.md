# Phase19 Forensic vs SCBI_M5_GLOBAL

Phase19 legacy PF reproducido: 3.176
Phase19 sample reproducido: 3177
SCBI_M5_GLOBAL PF referencia: NA
SCBI_M5_GLOBAL sample referencia: NA
Nota: benchmark overnight protegido; solo lectura
Conclusion: Phase19 no puede reemplazar esta referencia porque la auditoria forense encontro fallas invalidantes.
