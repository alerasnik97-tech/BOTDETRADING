# Phase19 Forensic vs Phase13

Phase19 legacy PF reproducido: 3.176
Phase19 sample reproducido: 3177
Phase13 PF referencia: 1.620
Phase13 sample referencia: 210
Nota: London reclaim; no modificada
Conclusion: Phase19 no puede reemplazar esta referencia porque la auditoria forense encontro fallas invalidantes.
