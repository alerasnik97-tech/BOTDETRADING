# Phase19 Forensic vs Phase17

Phase19 legacy PF reproducido: 3.176
Phase19 sample reproducido: 3177
Phase17 PF referencia: 2.030
Phase17 sample referencia: 53
Nota: post-news; no modificada
Conclusion: Phase19 no puede reemplazar esta referencia porque la auditoria forense encontro fallas invalidantes.
