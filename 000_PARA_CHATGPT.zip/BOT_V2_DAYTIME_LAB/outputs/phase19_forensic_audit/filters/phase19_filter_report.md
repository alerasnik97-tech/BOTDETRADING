# Phase19 Filter Audit

Verdicto: PHASE19_FILTERS_OVERFIT_WARNING
Ablation saved in phase19_filter_ablation.csv.
The Friday/min-depth/window/max-trades/CHOCH filters are performance-selected in the available evidence.
No-rollover was not enforced by the legacy backtest; applying it after the fact changes the sample.
