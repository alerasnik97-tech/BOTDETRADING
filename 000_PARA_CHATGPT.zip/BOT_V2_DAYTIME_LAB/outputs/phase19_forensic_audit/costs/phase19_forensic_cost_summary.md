# Phase19 Cost Sensitivity

Verdicto: PHASE19_COST_WARNING
PF at +1.0 pip: 2.576
PF at +1.5 pips: 2.347
Nota: el stress degrada el resultado, pero la ejecucion base ya esta invalidada por BID/ASK y timing.
