# Phase19 Forensic Test Results

Verdicto: PHASE19_TESTS_FAILED
Tests run: 5
Passed: 1
Failures: 4
Errors: 0

## Raw output
```
test_phase19_uses_realistic_bid_ask_and_same_bar_policy (test_phase19_execution_bid_ask.TestPhase19ExecutionBidAsk.test_phase19_uses_realistic_bid_ask_and_same_bar_policy) ... FAIL
test_phase19_has_no_duplicate_or_overlapping_trades (test_phase19_multi_trade_daily_limit.TestPhase19MultiTradeDailyLimit.test_phase19_has_no_duplicate_or_overlapping_trades) ... FAIL
test_phase19_entry_uses_next_bar_open_and_native_m3 (test_phase19_signal_no_lookahead.TestPhase19SignalNoLookahead.test_phase19_entry_uses_next_bar_open_and_native_m3) ... FAIL
test_phase19_time_news_and_forced_close (test_phase19_time_news_guard.TestPhase19TimeNewsGuard.test_phase19_time_news_and_forced_close) ... FAIL
test_phase19_tp_sl_orientation_and_risk (test_phase19_tp_sl_math.TestPhase19TpSlMath.test_phase19_tp_sl_orientation_and_risk) ... ok

======================================================================
FAIL: test_phase19_uses_realistic_bid_ask_and_same_bar_policy (test_phase19_execution_bid_ask.TestPhase19ExecutionBidAsk.test_phase19_uses_realistic_bid_ask_and_same_bar_policy)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\BOT_V2_DAYTIME_LAB\tests\engine_safety\test_phase19_execution_bid_ask.py", line 13, in test_phase19_uses_realistic_bid_ask_and_same_bar_policy
    self.assertTrue(data["long_entry_ask_used"])
    ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: False is not true

======================================================================
FAIL: test_phase19_has_no_duplicate_or_overlapping_trades (test_phase19_multi_trade_daily_limit.TestPhase19MultiTradeDailyLimit.test_phase19_has_no_duplicate_or_overlapping_trades)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\BOT_V2_DAYTIME_LAB\tests\engine_safety\test_phase19_multi_trade_daily_limit.py", line 15, in test_phase19_has_no_duplicate_or_overlapping_trades
    self.assertEqual(data["same_timestamp_trade_count"], 0)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 2145 != 0

======================================================================
FAIL: test_phase19_entry_uses_next_bar_open_and_native_m3 (test_phase19_signal_no_lookahead.TestPhase19SignalNoLookahead.test_phase19_entry_uses_next_bar_open_and_native_m3)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\BOT_V2_DAYTIME_LAB\tests\engine_safety\test_phase19_signal_no_lookahead.py", line 13, in test_phase19_entry_uses_next_bar_open_and_native_m3
    self.assertTrue(data["entry_occurs_next_bar_open"], "Phase19 must enter on next bar open, not CHOCH close")
    ~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: False is not true : Phase19 must enter on next bar open, not CHOCH close

======================================================================
FAIL: test_phase19_time_news_and_forced_close (test_phase19_time_news_guard.TestPhase19TimeNewsGuard.test_phase19_time_news_and_forced_close)
----------------------------------------------------------------------
Traceback (most recent call last):
  File "C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\BOT_V2_DAYTIME_LAB\tests\engine_safety\test_phase19_time_news_guard.py", line 15, in test_phase19_time_news_and_forced_close
    self.assertEqual(data["trades_open_after_2000"], 0)
    ~~~~~~~~~~~~~~~~^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
AssertionError: 375 != 0

----------------------------------------------------------------------
Ran 5 tests in 0.006s

FAILED (failures=4)
```
