# Phase19 Time / News / Rollover Audit

Verdicto: PHASE19_TIME_NEWS_INVALIDATES_PHASE19
Trades antes de 07:00 NY: 0
Trades despues de 20:00 NY: 0
Trades abiertos despues de 20:00 NY: 375
News violations +/-30m: 458
Conclusion: el codigo legacy no aplica news guard ni forced close 20:00.
