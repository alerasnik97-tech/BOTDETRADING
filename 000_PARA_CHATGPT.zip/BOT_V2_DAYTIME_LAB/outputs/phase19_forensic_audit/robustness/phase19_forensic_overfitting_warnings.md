# Phase19 Robustness Warnings

- Legacy robustness is numerically strong, but it is downstream of invalid execution/data/multitrade assumptions.
- 2015-2019 is available but uses the same synthetic M3 construction.
