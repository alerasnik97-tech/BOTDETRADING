# Phase19 Temporal Robustness

Verdicto: PHASE19_ROBUSTNESS_WARNING
Negative years: 0
Negative months: 4
PF 2020-2022: 3.303
PF 2023-2025: 3.127
Nota: la robustez numerica no rescata una ejecucion invalida.
