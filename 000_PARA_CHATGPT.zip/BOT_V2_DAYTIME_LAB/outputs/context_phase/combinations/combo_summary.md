# Phase 3: Strategic Combinations Results

 sample_size  tp_count  sl_count  win_rate     pf  expectancy      combo_name  verdict
         111        38        73    0.3423 1.0411      0.0224 PWH_DXY_ALIGNED REJECTED
          70        13        57    0.1857 0.5702     -0.3182  PWH_ASIA_SMALL REJECTED
          53        13        40    0.2453 0.9750     -0.0161   PDH_PWH_COMBO REJECTED