# Phase 1: Individual Context Filters Results

 sample_size  tp_count  sl_count  win_rate     pf  expectancy       filter_name                    verdict
         381       138       243    0.3622 1.1358      0.0679          BASELINE      FILTER_USEFUL_CONTEXT
         412       150       262    0.3641 1.1450      0.0691      LEVEL_ASIA_H      FILTER_USEFUL_CONTEXT
         381       138       243    0.3622 1.1358      0.0679    LEVEL_LONDON_H      FILTER_USEFUL_CONTEXT
         118        46        72    0.3898 1.2778      0.1290         LEVEL_PWH      FILTER_USEFUL_CONTEXT
          59        19        40    0.3220 0.9500     -0.0253         LEVEL_PMH FILTER_REJECTED_LOW_SAMPLE
         381       138       243    0.3622 1.1358      0.0679 PENETRATION_MIN_2      FILTER_USEFUL_CONTEXT
         381       138       243    0.3622 1.1358      0.0679 PENETRATION_MIN_5      FILTER_USEFUL_CONTEXT
         168        58       110    0.3452 1.0545      0.0314  ASIA_SIZE_MAX_30      FILTER_REJECTED_WORSE
         278        97       181    0.3489 1.0718      0.0389  ASIA_SIZE_MAX_50      FILTER_REJECTED_WORSE
         214        75       139    0.3505 1.0791      0.0381  DAYS_TUE_WED_THU      FILTER_REJECTED_WORSE
         296       111       185    0.3750 1.2000      0.0946 DXY_ALIGNED_SHORT      FILTER_USEFUL_CONTEXT