# Baseline M3 FVG Reconfirmation (2015-2026)

* **Sample:** 2231
* **PF:** 0.8384
* **Expectancy (R):** -0.0892
* **Win Rate:** 29.54%
* **TP/SL Count:** 659 / 1572
* **Max Loss Streak:** 24
* **Yearly Performance (PF):**
{
  "2015": 1.0707,
  "2016": 0.8029,
  "2017": 0.7746,
  "2018": 0.9848,
  "2019": 0.9536,
  "2020": 0.8366,
  "2021": 0.9272,
  "2022": 0.9683,
  "2023": 0.5926,
  "2024": 0.6753,
  "2025": 0.8429,
  "2026": 0.5
}

---
*Veredicto Actual:* **NO_CANDIDATE_FOUND_PHASE3**
