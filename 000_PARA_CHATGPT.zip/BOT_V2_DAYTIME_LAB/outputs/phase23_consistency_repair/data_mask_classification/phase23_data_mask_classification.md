
# DATA QUALITY MASK CLASSIFICATION

## 1. Auditoría de Impacto
- **Estado Original**: Phase 22 no aplicaba la máscara en el script de optimización.
- **Impacto Full (2020-2026)**: Elimina **37 trades**.
- **PnL Change**: 261.7 R -> 252.3 R (-9.4 R).

## 2. Clasificación Institucional
- **Tipo**: **WARNING**.
- **Justificación**: La Data Quality Mask es una restricción objetiva previa basada en integridad de datos, no en resultados de trading. Su aplicación reduce el sesgo de "trades imposibles" en gaps de datos.
- **Veredicto**: No invalida la Phase 22, pero se debe reportar que el performance real esperado es el filtrado por máscara.

**Resolución**: Configuración de Forward Demo exige `data_quality_mask: ENABLED (Fail-Closed)`.
