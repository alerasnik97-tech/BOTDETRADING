
# PHASE 23 METRICS RECONCILIATION

## 1. Mismatch Detectado
- **Reporte Narrativo (Obsoleto)**: PF 1.72, WR 55.2%.
- **Evidencia Trade-Level (Auditoría)**: PF 2.32, WR 39.8%.

## 2. Reconciliación Oficial
| Métrica | Valor Final | Fuente |
| :--- | :--- | :--- |
| **Sample** | 1048 | `phase22_be_05_audit_full.csv` |
| **Profit Factor** | **2.32** | Re-cálculo sobre 1048 trades (2020-2026). |
| **Winrate (TP)** | **39.8%** | 417 TPs sobre 1048 totales. |
| **Winrate (TP+BE)** | **74.4%** | (417 + 363) sobre 1048 totales. |

## 3. Resolución de Discrepancias
- El **PF 1.72** era una estimación conservadora manual que subestimaba el potencial real del sistema tras la optimización de la Phase 22.
- El **WR 55.2%** era inconsistente con la lógica de TP 1.1 / SL 1.0 fija (requeriría un AvgWin mucho mayor). Se descarta a favor del **39.8% (Auditoría)**.
- El **PF 1.64** se identifica como el resultado del stress test de deslizamiento (+0.5 pip) sobre el candidato original.

**Veredicto de Reconciliación**: Las métricas auditadas (2.32 PF) son las que mandan sobre la narrativa previa.
