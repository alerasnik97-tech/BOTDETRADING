# PHASE 7 REPAIRED BASELINE LOCKED

**ID:** PHASE7_REPAIRED_BASELINE_LOCKED
**Fecha:** 2026-04-26
**Veredicto:** PHASE8_BASELINE_READY

## 1. Métricas de Referencia (Congeladas)
- **Sample:** 347 trades
- **Profit Factor:** 1.50
- **Expectancy:** +0.183 R
- **Max Drawdown:** -8.0 R
- **Win Rate:** 36.6%
- **Max Loss Streak:** 11 trades

## 2. Configuración Congelada
- **Setup:** H1 sweep -> M3 First CHoCH (N=8)
- **Confirmation Delay:** REALTIME_CONFIRMED_FRACTAL_N8
- **Operational Window:** 08:30–11:00 NY
- **Volatility Filter:** ATR H1 > 12 pips
- **Trend Filter:** Contra EMA 50 H1
- **Management:** TP 1.5R, SL Extreme + 0.5 pips
- **News Guard:** ±30m high impact
- **Execution:** Realistic BID/ASK/SPREAD

## 3. Estado de Auditoría
- **Lookahead:** ZERO (Validated)
- **Execution:** REALISTIC (Validated)
- **News:** ZERO VIOLATIONS (Validated)

---
*Este documento es el benchmark oficial para el Phase 8 Improvement Lab.*
