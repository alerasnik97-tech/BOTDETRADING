# PHASE 14 STARTING POINT - BEST CANDIDATE SEARCH

**Objetivo:** Encontrar el mejor candidato diurno EURUSD en la ventana operativa 07:00–20:00 NY, evaluando gestiones avanzadas para estrategias previas y 3 nuevas líneas de investigación.

## Certificación de Seguridad e Integridad
- **Raíz Oficial:** `C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo` (Confirmado).
- **Engine Safety Gate:** **PASSED** (Confirmado).
- **Estatus Phase 12:** **INVALIDADA** (Confirmado).
- **SCBI_M5_GLOBAL:** **PROTEGIDA** (Confirmado).
- **Horario de Operación:** 07:00–20:00 NY (Mandatorio).
- **Cierre Forzado:** Todas las operaciones deben cerrar a las 20:00 NY (Mandatorio).

## Referencias de Autoridad (Benchmarks)
- **Phase 7 Repaired:** PF ~1.50 (Equilibrado).
- **Phase 8 High Precision:** PF ~2.09 (Baja frecuencia).
- **Phase 13 London Reclaim:** PF ~1.62 (Práctico).

## Líneas de Investigación Phase 14
1. **Bloque A:** Optimización de gestión (TP, BE, Parciales, Timeout) para Phase 7, 8 y 13.
2. **Bloque B - Estrategia Nueva 1:** HTF Flex Sweep (H4/H1/M30/M15) + LTF Confirmación.
3. **Bloque B - Estrategia Nueva 2:** London Range Reclaim Continuation (Foco NY session).
4. **Bloque B - Estrategia Nueva 3:** Opening Range Fakeout / Retest (Foco 07:00-09:30).

## Criterio de Éxito
- **Strong Candidate:** PF >= 1.64, muestra sólida, robustez 2023-2025.
- **Veredicto Final:** Ranking de mejores candidatos globales y prácticos.
