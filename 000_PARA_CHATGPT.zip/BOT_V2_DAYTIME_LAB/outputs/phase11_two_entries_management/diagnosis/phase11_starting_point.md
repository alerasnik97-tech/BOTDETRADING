# PHASE 11 STARTING POINT: DIAGNOSIS

## 1. Estado de la Estrategia Diurna (EURUSD)
Tras 10 fases de investigación, el ecosistema de BOT V2 se divide en:

- **Phase 8 High Precision (N=8 + Body 60% + No Fri):** PF 2.09. El estándar de oro. Frecuencia baja (1.2/mes).
- **Phase 7 Repaired (N=8):** PF 1.50. Más balanceada. Frecuencia media/baja (2.6/mes).
- **Phase 10 Selective Fakeout V2:** PF 1.317. Frecuencia media (9.4/mes). Muestra potencial pero requiere refinamiento en gestión.

## 2. Lecciones de la Phase 9/10
- La alta frecuencia (20-30 trades/mes) destruye el PF (0.80 - 1.10) si se basa en relajar filtros de sweeps.
- La selectividad extrema es la fuente del Profit Factor.
- No se ha explorado a fondo la **gestión dinámica** (BE, Timeouts, Parciales) como motor de mejora de los candidatos actuales.

## 3. Objetivos de la Phase 11
1. **Diversificar Entradas:** Método de Pullback (Tendencia) y Método de Extensión (Reversión Estadística).
2. **Optimizar Gestión:** Ver si BE o Salidas por Tiempo pueden salvar trades perdedores y aumentar la rotación de capital.
3. **Cierre de Ciclo:** Validar si un modelo con gestión superior puede alcanzar el PF 1.70 con una frecuencia saludable.

## 4. Vínculo con el Proyecto Principal
Se mantiene el respeto absoluto por `BOT DE TRADING ultimo`. La Phase 11 busca un "Hijo" robusto para la sesión de NY que acompañe al modelo overnight SCBI.
