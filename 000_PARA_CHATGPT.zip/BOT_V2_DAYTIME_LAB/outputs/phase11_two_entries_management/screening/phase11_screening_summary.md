# PHASE 11: NEW METHODS SCREENING SUMMARY

## 1. Resultados del Screening Inicial
| Método | Sample | Profit Factor | Expectancy | Veredicto |
|--------|--------|---------------|------------|-----------|
| **M1: Trend Pullback** | 4974 | **1.332** | +0.17 R | **PROCEED TO MGMT** |
| **M2: Axis Reversion** | 2708 | 0.095 | -0.71 R | **REJECTED_FATAL** |

## 2. Análisis del Método 1 (Trend Pullback)
- **Frecuencia:** ~70 trades/mes. Extremadamente alta.
- **Calidad:** PF 1.332 con gestión fija (1.5R).
- **Potencial:** Es el candidato ideal para aplicar BE y Timeouts para filtrar el ruido y aumentar el PF.

## 3. Fracaso del Método 2 (Axis Reversion)
- La reversión directa al eje H1 EMA 50 es suicida en el EURUSD actual. El precio suele "pegarse" a la tendencia una vez extendido.
- Se requiere un disparador estructural mucho más fuerte (CHoCH en M1) o confluencia de volumen.
- **Acción:** Se descarta la versión 1. Se explorará **M2 V2: VWAP Reversion** en el siguiente paso si el tiempo lo permite, o se priorizará el Método 1.

## 4. Próximos Pasos
- Pasar el **Método 1 (Trend Pullback)** a la matriz de gestión profunda (Fase 2).
- Retestear **Phase 8** y **Selective Fakeout** con gestión avanzada (Fase 3).
