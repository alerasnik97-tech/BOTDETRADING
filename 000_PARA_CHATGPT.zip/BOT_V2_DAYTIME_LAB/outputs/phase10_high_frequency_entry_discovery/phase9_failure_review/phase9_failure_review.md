# PHASE 9 FAILURE REVIEW: WHY RELAXATION FAILED

## 1. El Problema de la "Frecuencia Forzada"
En la Fase 9, intentamos alcanzar los 20 trades/mes relajando los filtros del candidato de la Fase 8. El resultado fue un colapso del Profit Factor de 2.09 a 0.82.

## 2. Hallazgos Críticos
- **Sequential Sweeps are Traps:** Permitir múltiples barridos en la misma sesión (sin límite de 1 trade/día o sin límite de primer barrido) expone al bot a ser "liquidez" en días de tendencia fuerte.
- **Body Filter Sensitivity:** El filtro de cuerpo de vela (60%) es vital para distinguir entre un CHoCH real (intención) y una simple absorción de liquidez que continuará la tendencia previa.
- **Friday Volatility:** Los viernes en EURUSD diurno presentan una micro-estructura mucho más ruidosa por cierres de posiciones semanales, lo que invalida el modelo de Mean Reversion simple.

## 3. Conclusión para la Fase 10
No se puede alcanzar alta frecuencia simplemente "haciendo lo mismo pero más veces". Se requiere una **nueva lógica de entrada** que aproveche otros comportamientos del mercado (Pullbacks, ORB, Displacement) manteniendo el contexto institucional de H1.

## 4. Qué NO Repetir
- No tomar cada sweep de cada nivel.
- No operar en contra de impulsos de desplazamiento fuerte sin confirmación estructural.
- No ignorar la calidad de la vela de entrada (displacement/body).
