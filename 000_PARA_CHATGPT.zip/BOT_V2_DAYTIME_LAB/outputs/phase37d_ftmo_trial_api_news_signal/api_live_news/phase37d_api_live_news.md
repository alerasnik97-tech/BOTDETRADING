# Phase37D API Live News

- provider configurado: TRADING_ECONOMICS, FMP, FINNHUB, EODHD
- API key presente localmente: False
- hoy cargado: False
- semana cargada: False
- estado: NO_TRADE_NEWS_PROVIDER_UNAVAILABLE
- gate: NO_TRADE
- proxima noticia bloqueante: None
