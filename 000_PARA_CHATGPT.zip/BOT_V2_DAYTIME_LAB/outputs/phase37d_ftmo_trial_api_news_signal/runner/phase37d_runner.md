# Phase37D Runner

- dry-run executed: True
- dry-run decision: STOP_BOT_ACTIVE
- auto runner started: False
- mode: NOT_STARTED
- risk: 0.005
- order_sent: False
- last decision: NO_TRADE
- reason: Full gate state is BLOCKED_NEWS_PROVIDER
