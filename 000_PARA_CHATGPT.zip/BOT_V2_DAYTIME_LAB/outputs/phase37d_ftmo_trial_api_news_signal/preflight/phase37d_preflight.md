# Phase37D Preflight

- timestamp_utc: 2026-04-29T13:56:32.791983+00:00
- cwd: C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo
- branch: main
- git_status: M .gitignore
 M 000_PARA_CHATGPT.zip
 M 00_READ_THIS_FIRST.md
 M 01_CURRENT_PROJECT_STATUS.json
 M 01_CURRENT_PROJECT_STATUS.md
 M 02_STRATEGY_AUTHORITY_MAP.json
 M 02_STRATEGY_AUTHORITY_MAP.md
 M BOT_V2_DAYTIME_LAB/ZIP_CONTENTS_MANIFEST.md
 M BOT_V2_DAYTIME_LAB/outputs/final_project_structure_manipulante/zip_validation/final_structure_zip_entries.txt
 M BOT_V2_DAYTIME_LAB/outputs/final_project_structure_manipulante/zip_validation/final_structure_zip_validation.json
 M BOT_V2_DAYTIME_LAB/outputs/final_project_structure_manipulante/zip_validation/final_structure_zip_validation.md
 M BOT_V2_DAYTIME_LAB/status.json
 M CHANGELOG.md
 M CLOUD_WORKFLOW.md
 M MANIPULANTE/00_LEER_PRIMERO/README_MANIPULANTE.md
 M MANIPULANTE/03_MT5_DEMO_LAUNCHER/ABRIR_MANIPULANTE_DEMO.bat
 M MANIPULANTE/03_MT5_DEMO_LAUNCHER/ABRIR_MANIPULANTE_DEMO.ps1
 M MANIPULANTE/03_MT5_DEMO_LAUNCHER/README_MT5_DEMO_LAUNCHER.md
 M MANIPULANTE/03_MT5_DEMO_LAUNCHER/mt5_path_config.json
 M MANIPULANTE/04_OPERACION_DIARIA/MANIPULANTE_DAILY_RUNBOOK.md
 M MANIPULANTE/04_OPERACION_DIARIA/MANIPULANTE_KILL_SWITCH.md
 M MANIPULANTE/12_MICRO_REAL_READINESS/MICRO_REAL_KILL_SWITCH.md
 M MANIPULANTE/12_MICRO_REAL_READINESS/MICRO_REAL_POSITION_SIZE_POLICY.md
 M README.md
 M ZIP_CONTENTS_MANIFEST.md
 M legacy_archive_2026/_audit_dest_extras.ps1
 M mt5_demo_executor_lab/mt5_order_router.py
 M reports/canonical_context_master_20260416_163108/AGENTS.md
 M reports/canonical_context_master_20260416_163108/RESEARCH_OPERATING_SYSTEM.md
 M reports/canonical_context_master_20260416_163108/RISK_PROTOCOL.md
 M reports/canonical_microstructure_iter2_20260416_172155/AGENTS.md
 M reports/canonical_microstructure_iter2_20260416_172155/RESEARCH_OPERATING_SYSTEM.md
 M reports/canonical_microstructure_iter2_20260416_172155/RISK_PROTOCOL.md
 M research_lab/README.md
?? BOT_V2_DAYTIME_LAB/ZIP_UPLOAD_IDENTITY_MARKER.md
?? BOT_V2_DAYTIME_LAB/configs/phase24_forward_demo_candidate_config.json
?? BOT_V2_DAYTIME_LAB/configs/phase24_forward_demo_candidate_config_hash.txt
?? BOT_V2_DAYTIME_LAB/configs/phase25_forward_demo_candidate_config.json
?? BOT_V2_DAYTIME_LAB/configs/phase25_forward_demo_candidate_config_hash.txt
?? BOT_V2_DAYTIME_LAB/configs/prop_firm_rules_config.json
?? BOT_V2_DAYTIME_LAB/docs/CANONICAL_ZIP_CHECKLIST.md
?? BOT_V2_DAYTIME_LAB/docs/CANONICAL_ZIP_OPERATING_STANDARD.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE25_DAILY_RUNBOOK.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE25_FORWARD_DEMO_PROTOCOL.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE25_FORWARD_REVIEW_CRITERIA.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE25_KILL_SWITCH_POLICY.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE26B_DATA_ACQUISITION_REQUIREMENTS_2015_2019.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE26B_DATA_CERTIFICATION_CHECKLIST_2015_2019.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32C_FUNDEDNEXT_CHECKOUT_VERIFICATION_CHECKLIST.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32C_FUNDEDNEXT_KILL_SWITCH.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32C_FUNDEDNEXT_PRE_TRADE_CHECKLIST.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32C_FUNDEDNEXT_STELLAR_LITE_OPERATIONAL_RULEBOOK.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32C_FUNDEDNEXT_WEEKEND_POLICY.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32_DAILY_RUNBOOK.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32_DUAL_LEDGER_PROTOCOL.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32_FTMO_PAPER_EVALUATION_PLAN.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32_KILL_SWITCH_POLICY.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32_REVIEW_CRITERIA.md
?? BOT_V2_DAYTIME_LAB/docs/PHASE32_RISK_POLICY.md
?? BOT_V2_DAYTIME_LAB/reports/PHASE36R_37A_ORDER_SEND_REPAIR_MICRO_REAL_GATE_REPORT.json
?? BOT_V2_DAYTIME_LAB/reports/PHASE36R_37A_ORDER_SEND_REPAIR_MICRO_REAL_GATE_REPORT.md
?? BOT_V2_DAYTIME_LAB/reports/PHASE36S_LIVE_NEWS_LOT_FEASIBILITY_REPORT.json
?? BOT_V2_DAYTIME_LAB/reports/PHASE36S_LIVE_NEWS_LOT_FEASIBILITY_REPORT.md
?? BOT_V2_DAYTIME_LAB/reports/PHASE36_LIVE_NEWS_MT5_DRYRUN_READINESS_REPORT.json
?? BOT_V2_DAYTIME_LAB/reports/PHASE36_LIVE_NEWS_MT5_DRYRUN_READINESS_REPORT.md
?? BOT_V2_DAYTIME_LAB/reports/PHASE37B_FTMO_TRIAL_NEWS_SIGNAL_FINALIZATION_REPORT.json
?? BOT_V2_DAYTIME_LAB/reports/PHASE37B_FTMO_TRIAL_NEWS_SIGNAL_FINALIZATION_REPORT.md
?? BOT_V2_DAYTIME_LAB/reports/PHASE37C_FULL_AUTO_FTMO_TRIAL_BOOTSTRAP_REPORT.json
?? BOT_V2_DAYTIME_LAB/reports/PHASE37C_FULL_AUTO_FTMO_TRIAL_BOOTSTRAP_REPORT.md
?? BOT_V2_DAYTIME_LAB/reports/PHASE37D_FTMO_TRIAL_API_NEWS_SIGNAL_AUTO_REPORT.json
?? BOT_V2_DAYTIME_LAB/reports/PHASE37D_FTMO_TRIAL_API_NEWS_SIGNAL_AUTO_REPORT.md
?? BOT_V2_DAYTIME_LAB/reports/PHASE37_FTMO_SWING_FREE_TRIAL_AUTOMATION_REPORT.json
?? BOT_V2_DAYTIME_LAB/reports/PHASE37_FTMO_SWING_FREE_TRIAL_AUTOMATION_REPORT.md
?? BOT_V2_DAYTIME_LAB/src/BOT_V2_DAYTIME_LAB/
?? BOT_V2_DAYTIME_LAB/src/phase36_exness_lot_validator.py
?? BOT_V2_DAYTIME_LAB/src/phase36_exness_symbol_gate.py
?? BOT_V2_DAYTIME_LAB/src/phase36_live_data_quality_gate.py
?? BOT_V2_DAYTIME_LAB/src/phase36_live_news_fortress.py
?? BOT_V2_DAYTIME_LAB/src/phase36_manipulante_dry_run_engine.py
?? BOT_V2_DAYTIME_LAB/src/phase36_readiness_orchestrator.py
?? BOT_V2_DAYTIME_LAB/src/phase36_server_time_validator.py
?? BOT_V2_DAYTIME_LAB/src/phase36_time_gate_validator.py
?? BOT_V2_DAYTIME_LAB/src/phase36r_37a_micro_real_gate_orchestrator.py
?? BOT_V2_DAYTIME_LAB/src/phase36s_live_news_lot_feasibility_orchestrator.py
?? BOT_V2_DAYTIME_LAB/src/phase36s_lot_feasibility_100usd.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_account_gate.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_live_news_consumer.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_lot_validator.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_symbol_data_gate.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_time_gate.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_trial_automation_orchestrator.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_trial_bot_runner.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_trial_order_router.py
?? BOT_V2_DAYTIME_LAB/src/phase37_ftmo_trial_support.py
?? BOT_V2_DAYTIME_LAB/src/phase37_micro_real_engine.py
?? BOT_V2_DAYTIME_LAB/src/phase37b_ftmo_trial_news_signal_finalization.py
?? BOT_V2_DAYTIME_LAB/src/phase37c_auto_install_calendar_bridge.py
?? BOT_V2_DAYTIME_LAB/src/phase37c_calendar_bridge_autostart.py
?? BOT_V2_DAYTIME_LAB/src/phase37c_full_auto_ftmo_trial_bootstrap.py
?? BOT_V2_DAYTIME_LAB/src/phase37c_live_news_cache_validator.py
?? BOT_V2_DAYTIME_LAB/src/phase37c_live_news_gate.py
?? BOT_V2_DAYTIME_LAB/src/phase37c_manipulante_live_signal_engine.py
?? BOT_V2_DAYTIME_LAB/src/phase37c_mt5_terminal_autodetect.py
?? BOT_V2_DAYTIME_LAB/src/phase37d_ftmo_trial_api_news_signal_auto.py
?? BOT_V2_DAYTIME_LAB/src/phase37d_live_news_api_adapter.py
?? BOT_V2_DAYTIME_LAB/src/phase37d_manipulante_live_signal_engine.py
?? LEER_PARA_SUBIR_ZIP.txt
?? MANIPULANTE/03_MT5_DEMO_LAUNCHER/ABRIR_FTMO_TRIAL_MANIPULANTE.bat
?? MANIPULANTE/03_MT5_DEMO_LAUNCHER/ABRIR_FTMO_TRIAL_MANIPULANTE.ps1
?? MANIPULANTE/03_MT5_DEMO_LAUNCHER/MANIPULANTE_DRY_RUN_MODE.md
?? MANIPULANTE/03_MT5_DEMO_LAUNCHER/MANIPULANTE_WATCH_ONLY_CONFIG.json
?? MANIPULANTE/08_CHECKLISTS/CHECKLIST_LIVE_NEWS_GATE.md
?? MANIPULANTE/09_COMPLIANCE/API_LIVE_NEWS_PROVIDER/
?? MANIPULANTE/09_COMPLIANCE/LIVE_NEWS_FORTRESS_POLICY.md
?? MANIPULANTE/09_COMPLIANCE/MT5_LIVE_NEWS_ADAPTER/
?? MANIPULANTE/09_COMPLIANCE/live_news_cache/
?? MANIPULANTE/09_COMPLIANCE/live_news_fortress_config.json
?? MANIPULANTE/12_MICRO_REAL_READINESS/MICRO_REAL_ACTIVATION_PROTOCOL.md
?? MANIPULANTE/12_MICRO_REAL_READINESS/NO_REAL_UNTIL_CONFIRMATION.md
?? MANIPULANTE/13_FTMO_TRIAL_AUTOMATION/
?? SUBIR_ESTE_ZIP_A_CHATGPT.txt
?? ZIP_VALIDADO_SUBIR_ESTE.txt
?? bypass_zip_output.json
?? debug_zip_identity_output.json
?? desktop_bypass_output.json
?? force_visible_zip_output.json
?? git_operations.py
?? inventory_check.py
?? legacy_archive_2026/000_PARA_CHATGPT_BACKUP_20260421_211526.zipbak
?? legacy_archive_2026/_test.zipbak
?? mt5_demo_executor_lab/mt5_order_router.py.phase36r_backup
?? phase34_core_docs_audit.py
?? phase34_git_push.py
?? phase34_manipulante_shadow_sync.py
?? phase34_manipulante_validation.py
?? phase34_path_audit.py
?? phase34_preflight.py
?? phase34_python_path_audit.py
?? phase34_report_generator.py
?? phase34_update_master_docs.py
?? phase35_structure_audit.py
?? preflight_check.py
?? validation_check.py
?? zip_builder.py
- git_diff_stat: .gitignore                                         |   2 +
 000_PARA_CHATGPT.zip                               | Bin 4751906 -> 201229 bytes
 00_READ_THIS_FIRST.md                              |  19 +-
 01_CURRENT_PROJECT_STATUS.json                     |  28 +-
 01_CURRENT_PROJECT_STATUS.md                       |  19 +-
 02_STRATEGY_AUTHORITY_MAP.json                     |  29 +-
 02_STRATEGY_AUTHORITY_MAP.md                       |  16 +-
 BOT_V2_DAYTIME_LAB/ZIP_CONTENTS_MANIFEST.md        |  14 +-
 .../zip_validation/final_structure_zip_entries.txt |  60 +++++
 .../final_structure_zip_validation.json            |   8 +-
 .../final_structure_zip_validation.md              |   8 +-
 BOT_V2_DAYTIME_LAB/status.json                     |  25 +-
 CHANGELOG.md                                       |   2 +-
 CLOUD_WORKFLOW.md                                  |   6 +-
 MANIPULANTE/00_LEER_PRIMERO/README_MANIPULANTE.md  |  33 +--
 .../ABRIR_MANIPULANTE_DEMO.bat                     |  19 +-
 .../ABRIR_MANIPULANTE_DEMO.ps1                     |  19 +-
 .../README_MT5_DEMO_LAUNCHER.md                    |  20 +-
 .../03_MT5_DEMO_LAUNCHER/mt5_path_config.json      |  10 +-
 .../MANIPULANTE_DAILY_RUNBOOK.md                   |  56 +---
 .../04_OPERACION_DIARIA/MANIPULANTE_KILL_SWITCH.md |  35 +--
 .../MICRO_REAL_KILL_SWITCH.md                      |   8 +-
 .../MICRO_REAL_POSITION_SIZE_POLICY.md             |   8 +-
 README.md                                          |   6 +-
 ZIP_CONTENTS_MANIFEST.md                           |  14 +-
 legacy_archive_2026/_audit_dest_extras.ps1         |   4 +-
 mt5_demo_executor_lab/mt5_order_router.py          | 297 ++++++++++++++++-----
 .../AGENTS.md                                      |   4 +
 .../RESEARCH_OPERATING_SYSTEM.md                   |   4 +
 .../RISK_PROTOCOL.md                               |   4 +
 .../AGENTS.md                                      |   4 +
 .../RESEARCH_OPERATING_SYSTEM.md                   |   4 +
 .../RISK_PROTOCOL.md                               |   4 +
 research_lab/README.md                             |   8 +-
 34 files changed, 447 insertions(+), 350 deletions(-)
warning: in the working copy of '.gitignore', LF will be replaced by CRLF the next time Git touches it
warning: in the working copy of 'mt5_demo_executor_lab/mt5_order_router.py', LF will be replaced by CRLF the next time Git touches it
- manipulante_exists: True
- manipulante_config_exists: True
- phase37c_report_exists: True
- ftmo_account_gate_exists: True
- router_order_send_gated: True
- bot_runner_exists: True
- canonical_zip_exists: True
- canonical_zip_testzip: None
- canonical_zip_sha256: 728d254ae811b11c9f7b770d013def63b6c2f97f46906278addd3914cd080b2f
- root_live_zip_count: 1
- no_secrets: True
- no_credentials: True
- no_real_account_saved: True
- no_order_send_without_gate: True
- critical_pass: True
