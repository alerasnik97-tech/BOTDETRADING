# Phase37D Signal Engine Equivalence

- state: MANIPULANTE_SIGNAL_SYNC_OK
- signal_status: NO_TRADE_GATE_BLOCK
- sync reason: Live engine reuses Phase18/Phase27 exact signal path
- live reason: Required gates not ALLOW: news=NO_TRADE; data=ALLOW; time=ALLOW
- source: Phase18 detectors + Phase27 generate_signals mapping.
- strategy changed: false
