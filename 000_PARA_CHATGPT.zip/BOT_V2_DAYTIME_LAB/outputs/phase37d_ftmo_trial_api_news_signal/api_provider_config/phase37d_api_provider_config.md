# Phase37D API Provider Config

- provider configurado: True
- provider priority: TRADING_ECONOMICS, FMP, FINNHUB, EODHD
- local config exists: True
- API key present locally: False
- local config excluded from Git/ZIP: true
