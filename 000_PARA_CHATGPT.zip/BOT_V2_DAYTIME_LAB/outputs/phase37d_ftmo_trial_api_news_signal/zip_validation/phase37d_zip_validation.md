# Phase37D ZIP Validation

- path: C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\000_PARA_CHATGPT.zip
- size: 201229
- entries: 199
- sha256: 728d254ae811b11c9f7b770d013def63b6c2f97f46906278addd3914cd080b2f
- testzip: None
- single_live_zip: True
- contains_phase37d_report: True
- contains_phase37d_outputs: True
- contains_api_adapter: True
- contains_signal_engine: True
- local_api_config_included: False
- heavy_entries_gt_2mb: []
- secret_like_entries: []
- zip_entries_inside: []
