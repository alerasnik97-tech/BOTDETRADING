# PF Math Audit Report

## Risk Distribution
- Mean Risk: 9.5879 pips
- Median Risk: 8.2000 pips
- Min Risk: 1.2000 pips
- Max Risk: 62.8000 pips
- **Micro-Risk Trades (<0.2 pips):** 0 (0.0%)

## Execution Realism
- **Same-bar Trades (M5):** 0 (0.0%)
- Avg Duration: 5.0 mins

## Mathematical Verification
- Gross Profit (R): 1628.00
- Gross Loss (R): 139.00
- Calculated PF: 11.712

## Findings
