# PRE-REPAIR REFERENCE: STRONG_CANDIDATE_PHASE7_V1

**Fecha:** 2026-04-26
**Veredicto:** PHASE7_REPAIR_REQUIRED

## 1. Métricas Originales (Auditadas)
- **Sample:** 329 trades
- **PF:** 1.643
- **Expectancy:** +0.225 R
- **Max Drawdown:** -5.5 R

## 2. Hallazgos Bloqueantes de la Auditoría
- **Lookahead Fractal:** El uso de `center=True` en la detección de fractales permite conocer picos/valles 8 velas antes de que sean visibles en tiempo real.
- **Ejecución Irrealista:** Las posiciones cortas cierran a precio BID (dataset) en lugar de ASK (spread), inflando artificialmente el resultado de los Shorts.
- **Fugas de Noticias:** 13 trades ignoraron el News Guard de ±30m.

## 3. Objetivo de Reparación
Eliminar el lookahead y corregir la ejecución sin alterar las reglas lógicas (N=8, EMA 50, ATR 12, TP 1.5R). El objetivo es obtener la métrica real y honesta del candidato.

---
*Documento de referencia inmutable para comparación post-repair.*
