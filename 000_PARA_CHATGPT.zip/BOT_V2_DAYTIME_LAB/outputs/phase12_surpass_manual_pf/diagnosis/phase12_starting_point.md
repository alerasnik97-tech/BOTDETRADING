# PHASE 12 STARTING POINT

**Fecha:** 2026-04-27
**Objetivo:** Identificar una estrategia diurna que supere el rendimiento manual del usuario (PF 1.64).

## 1. Benchmarks de Referencia
- **Manual Usuario:** PF 1.64 (Meta a superar).
- **Phase 8 High Precision:** PF ~2.09 (Calidad máxima, baja frecuencia).
- **Phase 7 Repaired:** PF ~1.50 (Candidato balanceado).
- **SCBI_M5_GLOBAL:** Benchmark superior overnight (Protegida).

## 2. Líneas de Investigación
- **Bloque A:** Retest de candidatos previos con matriz de gestión profunda.
- **Bloque B:** 2 nuevos métodos de entrada (H1 Sweep + Momentum y Session Rotation).

## 3. Restricciones Técnicas
- Datasets certificados con BID/ASK/SPREAD.
- News Guard mandatorio.
- No lookahead.
- No rollover.
