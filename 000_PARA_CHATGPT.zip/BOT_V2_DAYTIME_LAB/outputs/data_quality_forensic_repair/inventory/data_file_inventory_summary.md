# Data File Inventory Summary

Verdicto: DATA_FILES_LOCATED

Archivos auditados: 9

M1 BID/ASK rows: 2348053 / 2348053

M3 BID/ASK rows: 786429 / 786429
