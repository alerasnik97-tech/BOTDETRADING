# Data Quality Mask Summary

Mask: C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo\BOT_V2_DAYTIME_LAB\data\certified_m3\EURUSD_M3_DATA_QUALITY_MASK_2020_2026.csv

Phase19 blocked days: 67

Phase18 blocked days: 54
