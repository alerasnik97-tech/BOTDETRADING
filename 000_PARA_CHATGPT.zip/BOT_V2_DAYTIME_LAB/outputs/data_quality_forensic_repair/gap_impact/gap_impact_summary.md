# Gap Impact Summary

Total gaps: 739

Gaps dentro Phase19 08:00-16:30: 359

Gaps dentro Phase18 08:00-11:00: 338

Dias bloqueados Phase19 por mask: 67
