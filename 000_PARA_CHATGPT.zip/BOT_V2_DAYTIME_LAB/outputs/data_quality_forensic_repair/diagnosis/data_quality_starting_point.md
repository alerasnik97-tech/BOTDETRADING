# Data Quality Starting Point

- Phase18 protegida.
- Phase19 legacy invalidada.
- Phase19 repaired bloqueada.
- News Guard strict certificado.
- M3 no certificado por gaps.
- Objetivo actual: clasificar/reparar/certificar data, no correr estrategia.
