# Expected Market Calendar Summary

- Base: Forex EURUSD Sunday 17:00 NY to Friday 17:00 NY.
- Rollover: 17:00-19:00 NY diagnostic/maintenance.
- DST: America/New_York via timezone-aware pandas.
- Feriados especiales: no se inventan; si afectan ventanas, se enmascaran fail-closed.
