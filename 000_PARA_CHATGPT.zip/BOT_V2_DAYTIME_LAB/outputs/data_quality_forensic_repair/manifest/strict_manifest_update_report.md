# Strict Manifest Update Report

Verdicto: MANIFEST_UPDATED_WITH_MASKED_M3

M3 declarado: True
