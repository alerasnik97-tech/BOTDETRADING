# News Guard Strict Audit

Verdicto: NEWS_GUARD_STRICT_CERTIFIED
Rows raw/deduped: 1104 / 1090
High impact USD/EUR: 1090
