# M3 BID/ASK Certification Starting Point

- Phase19 sigue invalidada.
- Phase19 repaired sigue bloqueada hasta certificar M3 BID/ASK y News Guard.
- No se correran backtests de estrategia en esta fase.
- Phase18 sigue protegida.
- SCBI no se toca.
