# M3 Validation Summary

Verdicto: M3_REQUIRES_REPAIR

Tipo: M3_FROM_M1_BID_ASK_CERTIFIED

Rows: 786429

Critical gaps: 288
