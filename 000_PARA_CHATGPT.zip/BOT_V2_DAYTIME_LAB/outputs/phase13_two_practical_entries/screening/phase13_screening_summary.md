# Phase 13 Screening Summary - First Pass

**Veredicto Inicial:** Los modelos "Raw" de Sweep y Reclaim muestran un PF < 1.0 (0.86 - 0.91). Esto es esperado en modelos de reversión sin filtros de contexto.

## Resultados
| Sample | PF | Expectancy | Win Rate | Method | Variant |
|--------|----|------------|----------|--------|---------|
| 2433 | 0.91 | -0.054 | 0.3785 | sweep | body_0.5_size_1.0 |
| 2161 | 0.91 | -0.058 | 0.3767 | sweep | body_0.6_size_1.0 |
| 1622 | 0.91 | -0.055 | 0.3779 | sweep | body_0.6_size_1.2 |
| 1604 | 0.87 | -0.082 | 0.3672 | reclaim | session_asia_body_0.4 |
| 1492 | 0.87 | -0.083 | 0.3666 | reclaim | session_asia_body_0.5 |
| 1745 | 0.86 | -0.089 | 0.3645 | reclaim | session_london_body_0.5 |

## Diagnóstico
- **Frecuencia:** Demasiado alta (~40 trades/mes).
- **Filtros:** Se requiere añadir HTF Bias (H1 EMA) y posiblemente refinar la ventana de entrada.
- **Gestión:** TP 1.5R fijo podría estar castigando el Win Rate en modelos de reversión media.

## Siguiente Paso (Fase 2)
Incorporar filtros de tendencia H1 y matriz de gestión (TP/BE/Partials) para filtrar el ruido y buscar el edge.
