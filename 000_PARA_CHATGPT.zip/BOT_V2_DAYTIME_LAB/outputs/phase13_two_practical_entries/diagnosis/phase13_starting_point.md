# PHASE 13 STARTING POINT - TWO NEW PRACTICAL ENTRIES

**Objetivo:** Encontrar estrategias diurnas para EURUSD que sean prácticas, reproducibles y honestas (PF > 1.35 razonable, PF > 1.64 ideal).

## Referencias de Autoridad
- **SCBI_M5_GLOBAL:** Benchmark superior overnight (Protegida).
- **Phase 7 Repaired:** PF ~1.50 (Candidato balanceado).
- **Phase 8 High Precision:** PF ~2.09 (Candidato de alta precisión).

## Estado de Fases Anteriores
- **Phase 9/10/11:** Rechazadas por degradación de edge al aumentar frecuencia o fallos en gestión.
- **Phase 12:** **INVALIDADA** por bug técnico (Sign Flip) y omisión de costos. Prohibida como referencia positiva.

## Integridad Técnica
- **Engine Safety Gate:** **PASSED** (16 tests superados).
- **Ejecución:** Bid/Ask/Spread realista. News Guard obligatorio. Sin lookahead.

## Líneas de Investigación Phase 13
1. **H1 Sweep + LTF Momentum Reversal:** Barrido de liquidez H1 + Vela de momentum LTF.
2. **Session Range Reclaim / Rotation:** Ruptura falsa de rango de sesión + Reclamo del rango.
3. **Optimización de Gestión:** Matriz de TP/SL/BE/Partials para maximizar robustez.
