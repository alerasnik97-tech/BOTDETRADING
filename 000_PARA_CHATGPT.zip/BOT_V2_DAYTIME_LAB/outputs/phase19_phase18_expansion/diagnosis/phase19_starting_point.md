# PHASE 19: PHASE18 EXPANSION, LTF SENSITIVITY AND MANAGEMENT OPTIMIZATION

## 1. Baseline Certificado (Phase 18)
- **Estrategia**: H1 Fractal Sweep + First 3M CHOCH.
- **Ventana Principal**: 08:00–11:00 NY.
- **Profit Factor Validado**: 1.63.
- **Muestra**: 1,040 trades (2020-2026).
- **Frecuencia**: ~16 trades/mes.
- **Estado**: **PHASE18_VALIDATED_FOR_FORWARD_DEMO**.

## 2. Objetivos de la Phase 19
- **Expansión de Ventana**: Evaluar rentabilidad en el rango completo 07:00-20:00 NY.
- **Sensibilidad LTF**: Probar entradas en M1, M3, M5 y M15.
- **Optimización de Gestión**: Matriz de TP (0.75R a 3.0R), Break Even, Parciales y Timeouts.
- **Frecuencia**: Evaluar si permitir 2 o 3 operaciones diarias mejora la expectancy sin aumentar el riesgo de ruina.
- **Filtros de Calidad**: Refinar la selección de señales mediante filtros de desplazamiento (displacement) y profundidad de barrido.

## 3. Reglas de Seguridad
- No se reemplaza Phase 18 a menos que la nueva variante sea estadísticamente superior y robusta.
- Prohibido el lookahead.
- Ejecución estricta Bid/Ask.
- Cierre forzado a las 20:00 NY.

---
**Estado Actual**: Fase 0 (Preflight) Completada. Iniciando Fase 1 (Reproducción Baseline).
