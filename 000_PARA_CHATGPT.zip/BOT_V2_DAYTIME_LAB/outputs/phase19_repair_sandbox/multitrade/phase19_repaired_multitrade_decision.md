# Phase19 Repaired Multitrade Decision

Multitrade probado: False
Bloqueado: True
Razon: 1_trade_day_not_screened_or_not_survived_pf_1_50
