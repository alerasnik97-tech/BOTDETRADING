# Phase19 Repaired Screening Summary

Verdicto: SCREENING_BLOCKED_NATIVE_M3_ABSENT
M3 nativo confirmado: False
Razon: M3_NATIVO_AUSENTE: manifest period period_2020_2026 must contain m3_bid and m3_ask
Filas de screening: 0

No se ejecuta screening real si no hay M3 nativo certificado.
