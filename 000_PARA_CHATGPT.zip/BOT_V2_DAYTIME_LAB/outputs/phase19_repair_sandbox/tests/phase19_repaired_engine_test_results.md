# Phase19 Repaired Engine Test Results

Verdicto: PHASE19_REPAIRED_ENGINE_TESTS_PASSED
Tests run: 8
Passed: 8
Failures: 0
Errors: 0

```
test_bid_ask_execution_long_and_short (test_phase19_repaired_engine.TestPhase19RepairedEngine.test_bid_ask_execution_long_and_short) ... ok
test_entry_is_next_bar_open (test_phase19_repaired_engine.TestPhase19RepairedEngine.test_entry_is_next_bar_open) ... ok
test_forced_close_and_no_rollover (test_phase19_repaired_engine.TestPhase19RepairedEngine.test_forced_close_and_no_rollover) ... ok
test_h1_fractal_no_lookahead (test_phase19_repaired_engine.TestPhase19RepairedEngine.test_h1_fractal_no_lookahead) ... ok
test_news_guard_blocks (test_phase19_repaired_engine.TestPhase19RepairedEngine.test_news_guard_blocks) ... ok
test_no_native_m3_aborts (test_phase19_repaired_engine.TestPhase19RepairedEngine.test_no_native_m3_aborts) ... ok
test_no_overlap_and_max_trades_per_day (test_phase19_repaired_engine.TestPhase19RepairedEngine.test_no_overlap_and_max_trades_per_day) ... ok
test_same_bar_conservative (test_phase19_repaired_engine.TestPhase19RepairedEngine.test_same_bar_conservative) ... ok

----------------------------------------------------------------------
Ran 8 tests in 0.055s

OK
```
