# Phase 16 Starting Point - Post-News Edge Expansion

## Phase 15 Freeze
- **Best Candidate:** S1 Post-News Continuation.
- **Metrics:** PF 1.95 | Sample 56 | Expectancy +0.477R.
- **Setup:** Block 60m, Range 15m, TP 2.0R.
- **Families:** CPI, NFP, Retail Sales, ECB.
- **Status:** PHASE15_CANDIDATE_PENDING_VALIDATION.

## Phase 16 Objectives
1. Reproduce Phase 15 results exactly to ensure engine consistency.
2. Breakdown performance by individual news families (CPI vs NFP vs ECB, etc.).
3. Expand sampling with more combos and refined entry logic (M1/M3, close outside).
4. Audit news timing and temporal robustness.
