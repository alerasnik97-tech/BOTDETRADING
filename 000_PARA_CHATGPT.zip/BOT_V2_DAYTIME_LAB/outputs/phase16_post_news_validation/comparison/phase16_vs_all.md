# Phase 16 Comparison against Referencias

## 1. Phase 16 vs Phase 15
- **Phase 15 (S1):** PF 1.95 (Combo: CPI/NFP/RETAIL/ECB).
- **Phase 16 (Top):** PF 2.03 (Combo A: CPI/NFP/ECB).
- **Mejora:** Al filtrar familias de menor calidad (Retail) y usar el cierre de vela (`close_outside`), el PF sube de 1.95 a 2.03.

## 2. Phase 16 vs Phase 7 (Balanced)
- **Phase 16 PF:** 2.03 (High conviction).
- **Phase 7 PF:** 1.50 (High frequency).
- **Verdict:** Phase 16 es superior en calidad por trade, pero Phase 7 es necesaria para mantener volumen operativo.

## 3. Phase 16 vs Phase 8 (High Precision)
- **Phase 16 PF:** 2.03.
- **Phase 8 PF:** 2.09.
- **Verdict:** Empate técnico en calidad. Phase 8 es puramente técnica (fractales), Phase 16 es puramente fundamental (noticias). Coexistencia ideal.

## 4. Phase 16 vs Phase 13 (London)
- **Phase 16 PF:** 2.03.
- **Phase 13 PF:** 1.62.
- **Verdict:** Phase 16 es el ancla de la sesión NY, Phase 13 es el ancla de Londres.

## 5. Phase 16 vs Manual (PF 1.64)
- **Phase 16 PF:** 2.03.
- **Verdict:** Supera el benchmark manual por un margen significativo (+0.39 PF).

## 6. Phase 16 vs SCBI (Overnight)
- **Verdict:** SCBI sigue siendo el benchmark maestro por volumen institucional. Phase 16 es la primera estrategia diurna validada que no depende de "barridos de liquidez" (sweeps) sino de regímenes de volatilidad por eventos.
