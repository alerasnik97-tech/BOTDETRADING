# SCORING_METHODOLOGY.md

## 1. Pesos del Score Compuesto
- **Expectancy (R):** 20%
- **Profit Factor (PF):** 15%
- **Max Drawdown:** 15%
- **Consistencia Anual:** 12%
- **Walk-forward Stability:** 10%
- **Tamaño de Muestra:** 8%
- **Trades/Mes:** 5%
- **Ratio TP vs SL:** 5%
- **Dependencia de BE:** 5%
- **Funding Compatibility:** 5%

## 2. Penalizaciones
- PF < 1.1: RECHAZO INMEDIATO.
- Drawdown > 15%: Penalización severa.
- Muestra < 100 trades: RECHAZO por falta de significancia.
- Dependencia de un solo año: Bandera roja de overfitting.
