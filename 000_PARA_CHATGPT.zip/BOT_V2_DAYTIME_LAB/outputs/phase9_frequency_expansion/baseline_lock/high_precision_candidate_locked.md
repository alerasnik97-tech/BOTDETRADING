# PHASE 9 HIGH PRECISION BASELINE LOCKED

**ID:** HIGH_PRECISION_LOW_FREQUENCY_BASELINE (Candidate B)
**Fecha:** 2026-04-26

## 1. Métricas de Referencia (Inmutables)
- **Sample:** 165 trades
- **Profit Factor:** 2.09
- **Expectancy:** +0.318 R
- **Win Rate:** 40.6%
- **Max Loss Streak:** 3
- **Frecuencia Mensual:** ~1.2 trades/mes (Muy baja)

## 2. Configuración Congelada
- **Filtro Body:** >= 60%
- **Días:** Excluye Viernes
- **Barrido:** Primer barrido del día solamente
- **Ventana:** 08:30–11:00 NY
- **Niveles:** PDH/PDL solamente

## 3. Objetivo Phase 9
Expandir la frecuencia hacia los 10-20 trades/mes sin destruir el edge. Si la expansión degrada el PF por debajo de 1.40, se rechazará la versión High Frequency.
