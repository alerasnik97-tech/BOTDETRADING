# Manual Data Inventory

## Files Summary
- **analytics (1).csv**: Main trade history. Contains 841 trades from 2020-01-02 to 2025-05-20.
- **Images (1.png to 7.png)**: Likely visual evidence of specific setups.

## Data Structure (analytics (1).csv)
- **Columns**: 22 columns including entry/exit times, prices, side, rPnL, and Risk/Reward.
- **Symbol**: Primarily OANDA:EURUSD.
- **Period**: 2020-01-02 to 2025-05-20.
- **Key Metrics Available**:
    - Result (via rPnL and status).
    - Entry/SL/TP prices.
    - Entry/Exit timestamps (NY time based on the format).
    - Side (Buy/Sell).

## Preliminary Findings
- The dataset is large enough for a robust comparison (800+ trades).
- All trades are for EURUSD.
- Performance data (PnL) is explicit.
