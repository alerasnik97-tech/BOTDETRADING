# PHASE 20: NEWS FORTRESS IMPACT + SAFE FREQUENCY RECOVERY

## 1. Contexto Institucional
La Phase 18 ha sido certificada como el baseline diurno (PF 1.63). Sin embargo, la implementación de la capa de seguridad **News Fortress** ha demostrado bloquear un 32% de las señales, lo que impacta la frecuencia operativa. La Phase 20 busca recuperar esa frecuencia expandiendo ventanas y temporalidades sin comprometer el principio de **Fail-Closed**.

## 2. Objetivos Principales
- Cuantificar forensemente el impacto de News Fortress en el Profit Factor y la Frecuencia de Phase 18.
- Identificar variantes seguras (PF > 1.50) con mayor frecuencia (15-20 trades/mes).
- Aplicar News Fortress de forma mandatoria en todas las pruebas.
- Validar robustez 2023-2025 y sensibilidad a costos.

## 3. Restricciones
- No se debilita la seguridad de noticias.
- No se toca Phase 18 original.
- No se usa Phase 19 legacy.
- No se toca MT5 ni trading real.

---
**Estado**: Fase 0 Completada. Iniciando Reproducción de Baseline (Fase 1).
