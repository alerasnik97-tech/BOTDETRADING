# Phase 15 vs Authorities Comparison

## S1 Post-News (Phase 15) vs Phase 7 (Balanced)
- **Phase 15 PF:** 1.95
- **Phase 7 PF:** 1.50
- **Verdict:** Phase 15 es superior en calidad (edge puro), pero Phase 7 tiene mucha mayor frecuencia. Phase 15 es un complemento de alta confianza.

## S1 Post-News (Phase 15) vs Phase 8 (High Precision)
- **Phase 15 PF:** 1.95
- **Phase 8 PF:** 2.09
- **Verdict:** Ambos son estrategias de "francotirador". Phase 8 se basa en fractales y sweeps, Phase 15 en catalizadores macro. Se pueden usar simultáneamente sin mucha correlación.

## S1 Post-News (Phase 15) vs Phase 13 (London Reclaim)
- **Phase 15 PF:** 1.95
- **Phase 13 PF:** 1.62
- **Verdict:** Phase 13 es el "caballo de batalla" de Londres. Phase 15 es el "especialista" de NY. No compiten por horario.

## S1 Post-News (Phase 15) vs SCBI (Overnight)
- **Verdict:** SCBI sigue siendo el benchmark institucional por volumen y estabilidad. Phase 15 añade valor en la sesión diurna, que antes estaba "muerta" para nosotros.
