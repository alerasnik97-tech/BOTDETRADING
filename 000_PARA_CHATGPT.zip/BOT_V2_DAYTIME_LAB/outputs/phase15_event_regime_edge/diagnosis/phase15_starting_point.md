# Phase 15 Starting Point - Event Regime Edge Search

## Status Summary
- **Phase 14 Result:** Search complete, no strong candidates found (PF < 1.64) in 07:00-20:00 NY for sweep/reclaim.
- **Current Authorities:** Phase 13 (PF 1.62), Phase 8 (PF 2.09), Phase 7 (PF 1.50).
- **Phase 12:** INVALIDATED.
- **Engine Safety Gate:** PASSED.

## Phase 15 Objective
To find a new source of edge in the NY daytime window (07:00-20:00) by moving away from conventional sweeps and focusing on:
1. Post-News continuation.
2. Volatility compression breakouts.
3. Session exhaustion fades.

## Operational Constraints
- 07:00-20:00 NY strictly.
- Rollover block (17:00-19:00 NY).
- Real BID/ASK/SPREAD.
- No lookahead.
