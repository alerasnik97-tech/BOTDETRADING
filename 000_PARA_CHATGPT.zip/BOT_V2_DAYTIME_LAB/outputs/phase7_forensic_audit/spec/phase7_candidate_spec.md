# ESPECIFICACIÓN CONGELADA: STRONG_CANDIDATE_PHASE7_V1

**Fecha de congelación:** 2026-04-26
**Estado:** SPEC_FROZEN_NO_OPTIMIZATION

## 1. Identidad del Candidato
- **Nombre:** STRONG_CANDIDATE_PHASE7_V1
- **Símbolo:** EURUSD
- **Propósito:** Reversión de liquidez HTF con confirmación LTF.

## 2. Parámetros de Estructura (Contexto)
- **Timeframe HTF:** H1.
- **Niveles de Liquidez:** PDH, PDL, PWH, PWL (H1 Bid).
- **Timeframe LTF:** M3.
- **Definición de Sweep:** Cruce del nivel HTF por el precio M3 (High > Level para Shorts, Low < Level para Longs).
- **Selectividad:** Solo se permite el **Primer Barrido del Día**. Si hay múltiples niveles o re-barridos, se ignora el resto una vez detectado el primer setup.

## 3. Lógica de Entrada (Trigger)
- **Setup:** First CHoCH (Change of Character) tras el barrido.
- **Fractalidad (N):** 8 velas (Fractal de 17 velas en total).
- **Confirmación:** Cierre de vela M3 por encima/debajo del último fractal opuesto post-barrido.
- **Filtro de Volatilidad:** ATR(14) en H1 debe ser **> 12 pips** al momento del setup.
- **Filtro de Dirección (Exhaustion):** 
    - *Short Entry*: Solo si el precio está **por encima** de la EMA 50 de H1.
    - *Long Entry*: Solo si el precio está **por debajo** de la EMA 50 de H1.

## 4. Gestión de Riesgo y Operativa
- **Horario NY:** 08:30 – 11:00 (Apertura de sesión y ventana de liquidez).
- **News Guard:** Bloqueo de 30 minutos (antes y después) de noticias de impacto (High Impact).
- **Stop Loss:** Extremo del barrido H1 (High/Low del sweep) + **0.5 pips** de buffer.
- **Take Profit:** Fijo en **1.5 R**.
- **Breakeven / Trail:** Ninguno (Fase de validación de edge puro).

## 5. Parámetros de Ejecución Realista
- **Modelado:** BID/ASK/SPREAD histórico real.
- **Ejecución:** ASK para Longs, BID para Shorts.
- **Slippage:** 0.0 pips (Base de auditoría).
- **Política Same-Bar:** Si TP y SL se tocan en la misma vela, se asume **SL** (Conservador).

---
*Cualquier desviación de esta especificación durante la auditoría será marcada como fallo de reproducción.*
