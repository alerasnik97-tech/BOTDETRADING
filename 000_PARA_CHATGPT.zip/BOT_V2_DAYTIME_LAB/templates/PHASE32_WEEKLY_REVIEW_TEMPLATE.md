# PHASE32 WEEKLY REVIEW

- Week:
- Trades:
- Phase25 R:
- Shadow R:
- News violations:
- Data Mask violations:
- Daily loss breach:
- Max loss breach:
- Weekly R drawdown:
- Kill switch triggered:
- Decision: CONTINUE / PAUSE_REVIEW
- Notes:
