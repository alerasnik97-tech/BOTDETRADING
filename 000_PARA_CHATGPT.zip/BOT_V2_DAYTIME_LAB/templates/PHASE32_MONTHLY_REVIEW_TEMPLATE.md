# PHASE32 MONTHLY REVIEW

- Month:
- Trades:
- Phase25 R:
- Shadow R:
- Phase25 WR:
- Shadow WR:
- Phase25 DD:
- Shadow DD:
- Daily loss breach:
- Max loss breach:
- Violations:
- Minimum sample reached:
- Decision: CONTINUE / PAUSE_REVIEW / READY_FOR_AUDIT
- Notes:
