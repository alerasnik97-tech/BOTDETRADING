# 04_INFRASTRUCTURE_ENGINEERING

Sistemas periféricos: dashboards, Telegram, packaging, scripts de mantenimiento.
No decide trades. Solo observa y comunica.
