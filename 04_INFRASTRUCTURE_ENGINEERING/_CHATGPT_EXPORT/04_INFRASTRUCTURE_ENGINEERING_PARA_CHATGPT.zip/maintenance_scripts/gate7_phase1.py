"""Gate 7 Architecture Migration - Phase 1: Create structure + move dirs"""
import os, shutil, csv

base = r"C:\Users\alera\Desktop\Bot\BOT DE TRADING ultimo"

# 1. Create institutional folders + subfolders
structure = {
    "01_CORE_PRODUCTION": ["strategies","execution_engine","configs","risk_controls","logs_live","releases","_CHATGPT_EXPORT"],
    "02_INCUBATION_STAGING": ["paper_trading","demo_accounts","shadow_ledgers","reconciliations","configs_demo","reports_forward","_CHATGPT_EXPORT"],
    "03_RESEARCH_LAB": ["experiments","backtests","reports","notebooks","synthetic_tests","gates","research_outputs","_CHATGPT_EXPORT"],
    "04_INFRASTRUCTURE_ENGINEERING": ["artifact_delivery","dashboards","telegram","monitoring","maintenance_scripts","packaging_tools","github_tools","_CHATGPT_EXPORT"],
    "05_MARKET_DATA_VAULT": ["forex/EURUSD/tick","forex/EURUSD/M1","forex/EURUSD/M5","forex/EURUSD/H1","forex/EURUSD/metadata","manual_data","calendars","manifests","data_quality_reports","_CHATGPT_EXPORT"],
    "06_GOVERNANCE_AND_COMPLIANCE": ["architecture/gate7_architecture_migration","risk_protocols","ftmo_rules","operating_protocols","gate_decisions","audit_registers","artifact_delivery","git_policy","agent_rules","_CHATGPT_EXPORT"],
    "07_BACKUPS": ["cold_storage","zipped_snapshots","old_deliveries","quarantines","git_bundles","restore_points","_CHATGPT_EXPORT"],
}
for folder, subs in structure.items():
    for s in subs:
        os.makedirs(os.path.join(base, folder, s), exist_ok=True)

# 2. Move directories - mapping current → target
moves = []
dir_map = [
    ("BOT_V2_DAYTIME_LAB", "03_RESEARCH_LAB/BOT_V2_DAYTIME_LAB"),
    ("BOT_MARKET_DATA", "05_MARKET_DATA_VAULT/BOT_MARKET_DATA"),
    ("data", "05_MARKET_DATA_VAULT/data"),
    ("DATA MANUAL", "05_MARKET_DATA_VAULT/manual_data/DATA_MANUAL"),
    ("data_usdjpy_2016_2019", "05_MARKET_DATA_VAULT/forex/USDJPY_2016_2019"),
    ("data_usdjpy_2016_2021", "05_MARKET_DATA_VAULT/forex/USDJPY_2016_2021"),
    ("data_usdjpy_2022_2025", "05_MARKET_DATA_VAULT/forex/USDJPY_2022_2025"),
    ("ESTRATEGIAS", "03_RESEARCH_LAB/experiments/ESTRATEGIAS"),
    ("LAB_STRATEGIES", "03_RESEARCH_LAB/experiments/LAB_STRATEGIES"),
    ("MANIPULANTE", "03_RESEARCH_LAB/experiments/MANIPULANTE_legacy"),
    ("STRATEGIES", "03_RESEARCH_LAB/experiments/STRATEGIES"),
    ("ARCHIVO_HISTORICO", "07_BACKUPS/old_deliveries/ARCHIVO_HISTORICO"),
    ("_ARCHIVO_HISTORICO_NO_SUBIR", "07_BACKUPS/quarantines/_ARCHIVO_HISTORICO_NO_SUBIR"),
    ("docs", "06_GOVERNANCE_AND_COMPLIANCE/operating_protocols/docs_legacy"),
    ("reports", "03_RESEARCH_LAB/reports/reports_legacy"),
    ("scripts", "04_INFRASTRUCTURE_ENGINEERING/maintenance_scripts/scripts_legacy"),
    ("00_ENTREGA_CHATGPT", "06_GOVERNANCE_AND_COMPLIANCE/artifact_delivery/00_ENTREGA_CHATGPT"),
    ("01_DOCUMENTACION_ACTUAL", "06_GOVERNANCE_AND_COMPLIANCE/operating_protocols/01_DOCUMENTACION_ACTUAL"),
    ("02_GITHUB_CONTROL", "06_GOVERNANCE_AND_COMPLIANCE/git_policy/02_GITHUB_CONTROL"),
    ("03_DATA_READONLY", "05_MARKET_DATA_VAULT/manifests/03_DATA_READONLY"),
    (".github", "04_INFRASTRUCTURE_ENGINEERING/github_tools/.github"),
    (".vscode", "04_INFRASTRUCTURE_ENGINEERING/.vscode"),
]

# 3. Move loose files
file_map = [
    ("README_PROYECTO_ACTUAL.md", "06_GOVERNANCE_AND_COMPLIANCE/operating_protocols/README_PROYECTO_ACTUAL.md"),
    ("000_PARA_CHATGPT.sha256.txt", "06_GOVERNANCE_AND_COMPLIANCE/artifact_delivery/000_PARA_CHATGPT.sha256.txt"),
    ("VERIFICACION_ZIP_CHATGPT.txt", "06_GOVERNANCE_AND_COMPLIANCE/artifact_delivery/VERIFICACION_ZIP_CHATGPT.txt"),
    ("LEER_PRIMERO_SUBIR_A_CHATGPT.txt", "06_GOVERNANCE_AND_COMPLIANCE/artifact_delivery/LEER_PRIMERO_SUBIR_A_CHATGPT.txt"),
]

for src_name, dst_rel in dir_map:
    src = os.path.join(base, src_name)
    dst = os.path.join(base, dst_rel.replace("/", os.sep))
    if os.path.exists(src):
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
        moves.append([src_name, dst_rel, "DIR", "OK"])
        print(f"DIR: {src_name} -> {dst_rel}")

for src_name, dst_rel in file_map:
    src = os.path.join(base, src_name)
    dst = os.path.join(base, dst_rel.replace("/", os.sep))
    if os.path.exists(src):
        os.makedirs(os.path.dirname(dst), exist_ok=True)
        shutil.move(src, dst)
        moves.append([src_name, dst_rel, "FILE", "OK"])
        print(f"FILE: {src_name} -> {dst_rel}")

# 4. Save manifest
g7dir = os.path.join(base, "06_GOVERNANCE_AND_COMPLIANCE", "architecture", "gate7_architecture_migration")
with open(os.path.join(g7dir, "MOVE_MANIFEST_AFTER.csv"), "w", newline="", encoding="utf-8") as f:
    w = csv.writer(f)
    w.writerow(["source","destination","type","status"])
    w.writerows(moves)

print(f"\nTotal moved: {len(moves)}")
